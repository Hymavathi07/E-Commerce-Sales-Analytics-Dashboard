-- Database: ecommerce_analytics

CREATE TABLE customers (
    customer_id VARCHAR(10) PRIMARY KEY,
    customer_name VARCHAR(100),
    segment VARCHAR(50),
    country VARCHAR(50),
    state VARCHAR(50),
    city VARCHAR(50)
);

CREATE TABLE products (
    product_id VARCHAR(10) PRIMARY KEY,
    category VARCHAR(50),
    sub_category VARCHAR(50),
    product_name VARCHAR(100),
    base_price NUMERIC(10,2)
);

CREATE TABLE orders (
    order_id VARCHAR(12) PRIMARY KEY,
    order_date TIMESTAMP,
    ship_date TIMESTAMP,
    customer_id VARCHAR(10) REFERENCES customers(customer_id),
    payment_method VARCHAR(30)
);

CREATE TABLE order_items (
    order_id VARCHAR(12) REFERENCES orders(order_id),
    product_id VARCHAR(10) REFERENCES products(product_id),
    quantity INT,
    discount NUMERIC(5,2),
    unit_price NUMERIC(10,2),
    revenue NUMERIC(12,2),
    profit NUMERIC(12,2),
    PRIMARY KEY (order_id, product_id)
);