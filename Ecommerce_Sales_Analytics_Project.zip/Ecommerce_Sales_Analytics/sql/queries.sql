-- 1) Total revenue, profit, orders
SELECT
    COUNT(DISTINCT o.order_id) AS total_orders,
    SUM(oi.revenue) AS total_revenue,
    SUM(oi.profit) AS total_profit
FROM orders o
JOIN order_items oi ON o.order_id = oi.order_id;

-- 2) Monthly revenue trend
SELECT
  DATE_TRUNC('month', o.order_date) AS month,
  SUM(oi.revenue) AS revenue,
  SUM(oi.profit) AS profit
FROM orders o
JOIN order_items oi ON o.order_id = oi.order_id
GROUP BY 1
ORDER BY 1;

-- 3) Top 10 products by revenue
SELECT p.product_id, p.product_name, p.category, SUM(oi.revenue) AS revenue
FROM order_items oi
JOIN products p ON p.product_id = oi.product_id
GROUP BY 1,2,3
ORDER BY revenue DESC
LIMIT 10;

-- 4) Customer segmentation: new vs returning (30-day window)
WITH first_purchase AS (
  SELECT customer_id, MIN(order_date) AS first_date
  FROM orders
  GROUP BY 1
), orders_with_flag AS (
  SELECT o.*, CASE WHEN o.order_date <= fp.first_date + INTERVAL '30 days' THEN 'New' ELSE 'Returning' END AS cust_type
  FROM orders o JOIN first_purchase fp USING (customer_id)
)
SELECT cust_type, COUNT(DISTINCT order_id) AS orders, SUM(oi.revenue) AS revenue
FROM orders_with_flag owf
JOIN order_items oi ON owf.order_id = oi.order_id
GROUP BY 1;

-- 5) Revenue by geography
SELECT c.country, c.state, c.city, SUM(oi.revenue) AS revenue, SUM(oi.profit) AS profit
FROM orders o
JOIN order_items oi ON o.order_id = oi.order_id
JOIN customers c ON c.customer_id = o.customer_id
GROUP BY 1,2,3
ORDER BY revenue DESC
LIMIT 50;

-- 6) Discount impact on quantity (simple elasticity proxy)
SELECT width_bucket(discount, 0, 0.5, 5) AS discount_bucket, AVG(quantity) AS avg_qty, SUM(revenue) AS revenue
FROM order_items
GROUP BY 1
ORDER BY 1;

-- 7) Cohort analysis (by first purchase month)
WITH firsts AS (
  SELECT customer_id, DATE_TRUNC('month', MIN(order_date)) AS cohort_month
  FROM orders GROUP BY 1
),
cohorts AS (
  SELECT o.customer_id, DATE_TRUNC('month', o.order_date) AS order_month
  FROM orders o
)
SELECT f.cohort_month, c.order_month,
       COUNT(DISTINCT o.order_id) AS orders,
       SUM(oi.revenue) AS revenue
FROM firsts f
JOIN cohorts c USING (customer_id)
JOIN orders o ON o.customer_id=c.customer_id AND DATE_TRUNC('month', o.order_date)=c.order_month
JOIN order_items oi ON oi.order_id=o.order_id
GROUP BY 1,2
ORDER BY 1,2;