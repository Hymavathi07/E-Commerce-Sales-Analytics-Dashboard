# E‑Commerce Sales Analytics Dashboard

An end‑to‑end analytics project featuring SQL, Python, and an interactive dashboard. Ideal for portfolios and apprenticeships.

## Contents
- `data/` – Synthetic datasets (`orders.csv`, `order_items.csv`, `customers.csv`, `products.csv`, `ecommerce_sales.csv` denormalized).
- `sql/` – `schema.sql` to create tables; `queries.sql` with analysis queries.
- `notebooks/` – `sales_analysis.ipynb` for cleaning, EDA, KPIs, and a simple forecast.
- `dashboard/` – Plotly HTML dashboard (`index.html`) + individual charts.
- `README.md` – You are here.

## Quick Start
1. Open `dashboard/index.html` to explore charts.
2. Open `notebooks/sales_analysis.ipynb` to run the analysis.
3. Load `sql/schema.sql` and import CSVs into your database (PostgreSQL/MySQL).
4. Run queries from `sql/queries.sql` to reproduce insights.

## Tableau / Power BI
- Import `data/ecommerce_sales.csv` into Tableau or Power BI.
- Suggested visuals:
  - Monthly Revenue (line chart)
  - Top Products by Revenue (bar)
  - Revenue by Geography (map/treemap)
  - Discount vs Quantity (scatter)
  - Customer Type (New vs Returning) – use calculated field based on first purchase date.
- Publish the dashboard as your portfolio link.

## Notes
- Data is synthetic and generated for educational purposes.